from django.db import models

class Post(models.Model): # Post 모델 정의
    title = models.CharField(max_length=30) # Char 는 제목이 보통 한줄로 끝나니까 Char로 지정해주고..
    content = models.TextField() # Text 는 여러 문장 쭉쭉 쓸때.. content는 기니까.. 길이 안넣었으니 default 값 들어갈것임

    created_at = models.DateTimeField(auto_now_add=True) # auto_now_add: 생성 시간을 자동으로 저장
    updated_at = models.DateTimeField(auto_now=True) # auto_now: 수정 시간을 자동으로 저장
    # authorL 추후 작성 예정

    def __str__(self): # 객체를 문자열로 표현할 때 사용
        return f'[{self.pk}]{self.title}' # pk: 객체의 고유한 번호, title: 제목. 게시물의 기본 키가 대괄호로
    def get_absolute_url(self): # get_absolute_url 메서드 정의
        return f'/blog/{self.pk}/' # 게시물의 상세 페이지 주소를 반환
    

# Create your models here.
